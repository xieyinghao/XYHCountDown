//
//  ViewController.m
//  MYCountDown
//
//  Created by Magic Yu on 16/7/1.
//  Copyright © 2016年 MagicYu. All rights reserved.
//

#import "ViewController.h"
#import "MYCountdownView.h"

@interface ViewController ()<MYCountdownViewDelegate>
@property (weak, nonatomic) IBOutlet MYCountdownView *countDownView;

@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.countDownView.delegate = self;
    self.countDownView.backgroundAlpha = 0.2;
    self.countDownView.countdownFrom = 4;
    
    [self.countDownView updateAppearance];
    
    
}

- (void) viewDidAppear:(BOOL)animated
{
    [self.countDownView start];
}

- (void) countdownFinished:(MYCountdownView *)view
{
    [self.countDownView removeFromSuperview];
    [self.view setNeedsDisplay];
    self.imgView.backgroundColor = [UIColor cyanColor];;
}


@end
