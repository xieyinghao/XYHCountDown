//
//  MYCountdownView.h
//
//  Created by MagicYu on 07/01/16.
//  Copyright (c) 2016 MagicYu All rights reserved.
//

#import <UIKit/UIKit.h>

static const int kDefaultCountdownFrom = 5;

@class MYCountdownView;

@protocol MYCountdownViewDelegate <NSObject>

@required
- (void) countdownFinished:(MYCountdownView *)view;

@end

@interface MYCountdownView : UIView

@property (nonatomic) int countdownFrom;

// appearance settings
@property (nonatomic) float backgroundAlpha;

@property (nonatomic, weak) id<MYCountdownViewDelegate> delegate;

- (void) updateAppearance;
- (void) start;
- (void) stop;

@end
