//
//  MYCountdownView.h
//
//
//  Created by MagicYu on 07/01/16.
//  Copyright (c) 2016 MagicYu All rights reserved.
//

#import "MYCountdownView.h"

@interface MYCountdownView ()

@property (nonatomic) NSTimer* timer;
@property (nonatomic) UIImageView* imgView;

@property (nonatomic) int currentCountdownValue;

@end


@implementation MYCountdownView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self updateAppearance];
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aCoder {
    if(self = [super initWithCoder:aCoder]){
        [self updateAppearance];
    }
    return self;
}

- (void) updateAppearance
{
    [[self subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    self.opaque = NO;
//    self.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:self.backgroundAlpha];
     self.backgroundColor = [UIColor whiteColor];
    self.imgView = [[UIImageView alloc] init];
    
    self.imgView.opaque = YES;
    self.imgView.alpha = 1.0;
    [self addSubview: self.imgView];
    
    self.imgView.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, 80, 80);
    [self.imgView setCenter:self.center];
    
    
    
}

- (void) layoutSubviews
{
    [super layoutSubviews];
    
    [self.imgView setCenter:self.center];

}

#pragma mark - start/stopping
- (void) start
{
    [self stop];
    self.currentCountdownValue = self.countdownFrom;
    
    
    
    self.imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%d",self.countdownFrom]];
    [self animate];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                  target:self
                                                selector:@selector(animate)
                                                userInfo:nil
                                                 repeats:YES];
}

- (void) stop
{
    if (self.timer && [self.timer isValid]) {
        [self.timer invalidate];
    }
}

#pragma mark - animation stuff

- (void) animate
{
    [UIView animateWithDuration:0.9 animations:^{
            
        self.imgView.alpha = 0;
        
    } completion:^(BOOL finished) {
        if (finished) {
        
            if (self.currentCountdownValue == 2) {
                
                CGRect frame = self.imgView.frame;
                frame = [UIScreen mainScreen].bounds;
                
                [UIView animateWithDuration:0.9 animations:^{
                    //self.imgView.center = self.center;
                    self.imgView.frame = frame;
                }];
            }
            
            
             [UIView animateWithDuration:0.8 animations:^{
                 self.imgView.alpha = 1.0;
             }];
             
            self.currentCountdownValue--;
        
            if (self.currentCountdownValue == 0) {
                
                [self stop];
                if (self.delegate) {
                    [self.delegate countdownFinished:self];
                    [self removeFromSuperview];
                }

            } else {
                self.imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%d",self.currentCountdownValue]];
            }
        }
    }];
}

#pragma mark - custom getters
- (float)backgroundAlpha
{
    if (_backgroundAlpha == 0) {
        _backgroundAlpha = 0.3;
    }
    
    return _backgroundAlpha;
}

- (int) countdownFrom
{
    if (_countdownFrom == 0) {
        _countdownFrom = kDefaultCountdownFrom;
    }
    
    return _countdownFrom;
}




@end
