//
//  AppDelegate.h
//  MYCountDown
//
//  Created by Magic Yu on 16/7/1.
//  Copyright © 2016年 MagicYu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

